# frozen_string_literal: true

class Logger
  VERSION = "1.7.0"
end
