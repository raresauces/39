#
# See the functionality in Minitest#load
#
warn "This file is no longer necessary. Called from #{caller.first}"
