require_relative "../minitest"

Minitest.load :pride
Minitest::PrideIO.pride!
