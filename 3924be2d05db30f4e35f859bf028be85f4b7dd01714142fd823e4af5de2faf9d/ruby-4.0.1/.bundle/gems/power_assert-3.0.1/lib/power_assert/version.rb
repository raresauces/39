module PowerAssert
  VERSION = "3.0.1"
end
